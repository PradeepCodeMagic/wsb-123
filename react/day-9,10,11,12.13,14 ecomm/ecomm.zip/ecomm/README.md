# React + Vite

for start
------ npm run dev